# Practical D-3 : Binary Search Tree (insert, search, delete, traversals)

class Node:
    def __init__(self, key):
        self.key = key
        self.left = None
        self.right = None


def insert(root, key):
    if root is None:
        return Node(key)
    if key < root.key:
        root.left = insert(root.left, key)
    elif key > root.key:
        root.right = insert(root.right, key)
    else:
        print("Duplicate key ignored:", key)
    return root


def search(root, key):
    if root is None or root.key == key:
        return root
    if key < root.key:
        return search(root.left, key)
    return search(root.right, key)


def min_node(root):
    while root.left is not None:
        root = root.left
    return root


def delete(root, key):
    if root is None:
        print("Key not found")
        return None
    if key < root.key:
        root.left = delete(root.left, key)
    elif key > root.key:
        root.right = delete(root.right, key)
    else:
        # Case 1 and 2 : zero or one child
        if root.left is None:
            return root.right
        if root.right is None:
            return root.left
        # Case 3 : two children -> use inorder successor
        succ = min_node(root.right)
        root.key = succ.key
        root.right = delete(root.right, succ.key)
    return root


def inorder(r):
    if r:
        inorder(r.left)
        print(r.key, end=" ")
        inorder(r.right)


def preorder(r):
    if r:
        print(r.key, end=" ")
        preorder(r.left)
        preorder(r.right)


def postorder(r):
    if r:
        postorder(r.left)
        postorder(r.right)
        print(r.key, end=" ")


def height(r):
    return 0 if r is None else 1 + max(height(r.left), height(r.right))


def read_key():
    # keys are treated as text if not a number (e.g. JAN, MON, J, R ...)
    s = input("Enter key: ").strip()
    return int(s) if s.lstrip("-").isdigit() else s


def main():
    root = None
    while True:
        print("\n----- BINARY SEARCH TREE -----")
        print("1. Insert\n2. Insert many keys\n3. Search\n4. Delete")
        print("5. Inorder\n6. Preorder\n7. Postorder\n8. Height\n9. Exit")
        ch = input("Enter your choice: ").strip()
        if ch == "1":
            root = insert(root, read_key())
        elif ch == "2":
            for s in input("Enter keys separated by space: ").split():
                root = insert(root, int(s) if s.lstrip("-").isdigit() else s)
        elif ch == "3":
            print("Found" if search(root, read_key()) else "Not found")
        elif ch == "4":
            root = delete(root, read_key())
        elif ch == "5":
            print("Inorder  :", end=" "); inorder(root); print()
        elif ch == "6":
            print("Preorder :", end=" "); preorder(root); print()
        elif ch == "7":
            print("Postorder:", end=" "); postorder(root); print()
        elif ch == "8":
            print("Height (levels) =", height(root))
        elif ch == "9":
            break
        else:
            print("Invalid choice")


main()
