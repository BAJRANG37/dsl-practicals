# Practical A-1 : List data structure (menu driven)
# Operations: append, insert, remove, pop, display, search, sort, reverse, len/max/min/sum

def main():
    a = []
    while True:
        print("\n----- LIST OPERATIONS -----")
        print("1. Append (add at end)")
        print("2. Insert at position")
        print("3. Remove a value")
        print("4. Pop (delete last / given index)")
        print("5. Display list")
        print("6. Search an element")
        print("7. Sort list")
        print("8. Reverse list")
        print("9. Length, Max, Min, Sum")
        print("10. Exit")
        ch = input("Enter your choice: ").strip()

        if ch == "1":
            x = int(input("Enter value: "))
            a.append(x)
            print("Added.", a)
        elif ch == "2":
            pos = int(input("Enter position (index): "))
            x = int(input("Enter value: "))
            a.insert(pos, x)
            print("Inserted.", a)
        elif ch == "3":
            x = int(input("Enter value to remove: "))
            if x in a:
                a.remove(x)
                print("Removed.", a)
            else:
                print("Value not found in list")
        elif ch == "4":
            if len(a) == 0:
                print("List is empty")
            else:
                i = input("Enter index (press Enter for last): ").strip()
                x = a.pop() if i == "" else a.pop(int(i))
                print("Popped element:", x, "List:", a)
        elif ch == "5":
            print("List =", a)
        elif ch == "6":
            x = int(input("Enter value to search: "))
            if x in a:
                print("Found at index", a.index(x), "| count =", a.count(x))
            else:
                print("Not found")
        elif ch == "7":
            a.sort()
            print("Sorted list:", a)
        elif ch == "8":
            a.reverse()
            print("Reversed list:", a)
        elif ch == "9":
            if a:
                print("Length =", len(a), "Max =", max(a), "Min =", min(a), "Sum =", sum(a))
            else:
                print("List is empty")
        elif ch == "10":
            print("Bye!")
            break
        else:
            print("Invalid choice")

main()
