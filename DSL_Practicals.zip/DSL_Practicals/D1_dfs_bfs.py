# Practical D-1 : Graph traversal - DFS and BFS (adjacency list)

def dfs(graph, u, visited):
    visited.append(u)
    for v in graph[u]:
        if v not in visited:
            dfs(graph, v, visited)


def bfs(graph, start):
    visited = [start]
    queue = [start]
    while queue:
        u = queue.pop(0)
        for v in graph[u]:
            if v not in visited:
                visited.append(v)
                queue.append(v)
    return visited


def sample_graph():
    # directed graph from the oral question sheet (D-1)
    return {
        'A': ['B', 'D'], 'B': ['C', 'F'], 'C': ['E', 'G', 'H'], 'D': ['F'],
        'E': ['B', 'F'], 'F': ['A'], 'G': ['E', 'H'], 'H': ['A'],
    }


def read_graph():
    graph = {}
    n = int(input("Enter number of vertices: "))
    print("Enter vertex names one by one:")
    for _ in range(n):
        graph[input("  vertex: ").strip()] = []
    e = int(input("Enter number of edges: "))
    directed = input("Is the graph directed? (y/n): ").strip().lower() == "y"
    for _ in range(e):
        u, v = input("  edge (u v): ").split()
        graph[u].append(v)
        if not directed:
            graph[v].append(u)
    for k in graph:
        graph[k].sort()
    return graph


def main():
    print("1. Use sample graph\n2. Enter my own graph")
    graph = sample_graph() if input("Choose: ").strip() == "1" else read_graph()
    print("\nAdjacency list:")
    for k, v in graph.items():
        print(" ", k, "->", v)
    start = input("Enter starting vertex: ").strip()
    visited = []
    dfs(graph, start, visited)
    print("DFS :", " -> ".join(visited))
    print("BFS :", " -> ".join(bfs(graph, start)))


main()
