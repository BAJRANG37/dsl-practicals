# Data Structures Laboratory (DSL) - SE Computer Engineering (2024 pattern)

Python programs for all DSL practicals. Every program is menu driven.

| File | Practical | Topic |
|------|-----------|-------|
| `A1_list_operations.py` | A-1 | List data structure and built-in functions |
| `A2_searching.py` | A-2 | Linear search and Binary search |
| `A3_sorting.py` | A-3 | Bubble sort and Selection sort (pass by pass) |
| `B1_stack.py` | B-1 | Stack operations, infix to postfix |
| `B2_simple_queue.py` | B-2 | Simple queue (shows its drawback) |
| `B3_circular_queue.py` | B-3 | Circular queue |
| `C1_hashing.py` | C-1, C-2 | Hashing: linear probing, quadratic probing, chaining |
| `D1_dfs_bfs.py` | D-1 | Graph traversal: DFS and BFS |
| `D3_binary_search_tree.py` | D-3 | BST: insert, search, delete, traversals |
| `D4_tree_traversals.py` | D-4 | Inorder / Preorder / Postorder, tree from Pre + In |

## How to run
Open this folder in VS Code, open a terminal (Ctrl + `) and run:

```
python3 A1_list_operations.py
```

On Windows use `python` instead of `python3`.

## How to upload to GitHub
```
git init
git add .
git commit -m "DSL practicals"
git branch -M main
git remote add origin https://github.com/<your-username>/<repo-name>.git
git push -u origin main
```
(Create an empty repository on github.com first and copy its URL.)
