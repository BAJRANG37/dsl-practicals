# Practical C-1 & C-2 : Hashing
# Hash function: h(k) = k % size
# Collision handling: 1) Linear probing  2) Quadratic probing  3) Separate chaining

def insert_open(table, key, method):
    """Open addressing. method = 'linear' or 'quadratic'. Returns index or -1."""
    m = len(table)
    h = key % m
    for i in range(m):
        if method == "linear":
            pos = (h + i) % m              # (h + i) mod m
        else:
            pos = (h + i * i) % m          # (h + i^2) mod m
        if table[pos] is None:
            table[pos] = key
            if i > 0:
                print(key, "-> collision at", h, ", placed at index", pos)
            else:
                print(key, "-> placed at index", pos)
            return pos
    print(key, "-> could NOT be inserted (no free slot found)")
    return -1


def search_open(table, key, method):
    m = len(table)
    h = key % m
    for i in range(m):
        pos = (h + i) % m if method == "linear" else (h + i * i) % m
        if table[pos] is None:
            return -1
        if table[pos] == key:
            return pos
    return -1


def show_open(table):
    print("Index | Key")
    for i, v in enumerate(table):
        print("%5d | %s" % (i, v if v is not None else "-"))


def show_chain(chains):
    print("Index | Chain")
    for i, c in enumerate(chains):
        print("%5d | %s" % (i, " -> ".join(str(x) for x in c) if c else "-"))


def main():
    m = int(input("Enter table size: "))
    print("1. Linear probing\n2. Quadratic probing\n3. Separate chaining")
    mode = input("Choose collision method: ").strip()
    table = [None] * m
    chains = [[] for _ in range(m)]
    method = "linear" if mode == "1" else "quadratic"

    while True:
        print("\n----- HASHING -----")
        print("1. Insert keys\n2. Search a key\n3. Display table\n4. Exit")
        ch = input("Enter your choice: ").strip()
        if ch == "1":
            keys = [int(x) for x in input("Enter keys separated by space: ").split()]
            for k in keys:
                if mode == "3":
                    chains[k % m].append(k)
                    print(k, "-> index", k % m)
                else:
                    insert_open(table, k, method)
        elif ch == "2":
            k = int(input("Enter key to search: "))
            if mode == "3":
                if k in chains[k % m]:
                    print("Found in chain at index", k % m)
                else:
                    print("Not found")
            else:
                p = search_open(table, k, method)
                if p != -1:
                    print("Found at index", p)
                else:
                    print("Not found")
        elif ch == "3":
            if mode == "3":
                show_chain(chains)
            else:
                show_open(table)
        elif ch == "4":
            break
        else:
            print("Invalid choice")


main()
