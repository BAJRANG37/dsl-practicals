# Practical A-2 : Linear Search and Binary Search

def linear_search(a, key):
    for i in range(len(a)):
        if a[i] == key:
            return i
    return -1


def binary_search(a, key):
    # list must be sorted
    low, high = 0, len(a) - 1
    step = 1
    while low <= high:
        mid = (low + high) // 2
        print("Step", step, ": low =", low, "high =", high, "mid =", mid, "a[mid] =", a[mid])
        step += 1
        if a[mid] == key:
            return mid
        elif a[mid] < key:
            low = mid + 1
        else:
            high = mid - 1
    return -1


def read_list():
    return [int(x) for x in input("Enter numbers separated by space: ").split()]


def main():
    a = read_list()
    print("List:", a)
    while True:
        print("\n----- SEARCHING -----")
        print("1. Linear Search")
        print("2. Binary Search")
        print("3. Enter a new list")
        print("4. Exit")
        ch = input("Enter your choice: ").strip()
        if ch == "1":
            key = int(input("Enter key to search: "))
            r = linear_search(a, key)
            if r != -1:
                print("Found at index", r, "(position", r + 1, ")")
            else:
                print("Key not found")
        elif ch == "2":
            b = sorted(a)
            print("Binary search needs a sorted list. Sorted list:", b)
            key = int(input("Enter key to search: "))
            r = binary_search(b, key)
            if r != -1:
                print("Found at index", r, "(position", r + 1, ")")
            else:
                print("Key not found")
        elif ch == "3":
            a = read_list()
            print("List:", a)
        elif ch == "4":
            break
        else:
            print("Invalid choice")


main()
