# Practical B-1 : Stack (array/list based) + Infix to Postfix conversion

MAX = 5
stack = []
top = -1          # top = -1 means stack is empty


def push(x):
    global top    # we change 'top' inside the function, so 'global' is needed
    if top == MAX - 1:
        print("Stack Overflow (stack is full)")
    else:
        top += 1
        stack.append(x)
        print(x, "pushed")


def pop():
    global top
    if top == -1:
        print("Stack Underflow (stack is empty)")
    else:
        x = stack.pop()
        top -= 1
        print(x, "popped")


def peek():
    if top == -1:
        print("Stack is empty")
    else:
        print("Top element =", stack[top])


def display():
    if top == -1:
        print("Stack is empty")
    else:
        print("Stack (top -> bottom):")
        for i in range(top, -1, -1):
            print("  ", stack[i])


# ---------- Infix to Postfix ----------
def precedence(op):
    if op == '^':
        return 3
    if op in '*/':
        return 2
    if op in '+-':
        return 1
    return 0


def infix_to_postfix(expr):
    st = []
    out = []
    for ch in expr.replace(" ", ""):
        if ch.isalnum():                 # operand
            out.append(ch)
        elif ch == '(':
            st.append(ch)
        elif ch == ')':
            while st and st[-1] != '(':
                out.append(st.pop())
            if st:
                st.pop()                 # remove '('
        else:                            # operator
            while st and st[-1] != '(' and precedence(st[-1]) >= precedence(ch):
                out.append(st.pop())
            st.append(ch)
        print("Symbol:", ch, "| Stack:", "".join(st), "| Output:", "".join(out))
    while st:
        out.append(st.pop())
    return "".join(out)


def main():
    while True:
        print("\n----- STACK -----")
        print("1. Push")
        print("2. Pop")
        print("3. Peek")
        print("4. Display")
        print("5. Infix to Postfix")
        print("6. Exit")
        ch = input("Enter your choice: ").strip()
        if ch == "1":
            push(int(input("Enter value: ")))
        elif ch == "2":
            pop()
        elif ch == "3":
            peek()
        elif ch == "4":
            display()
        elif ch == "5":
            e = input("Enter infix expression (e.g. (a+b)*c): ")
            print("Postfix =", infix_to_postfix(e))
        elif ch == "6":
            break
        else:
            print("Invalid choice")


main()
