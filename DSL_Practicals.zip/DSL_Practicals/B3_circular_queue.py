# Practical B-3 : Circular Queue (solves the drawback of the simple queue)
# Formulas:  rear = (rear + 1) % size     front = (front + 1) % size
#            Full : (rear + 1) % size == front        Empty : front == -1

class CircularQueue:
    def __init__(self, size):
        self.size = size
        self.q = [None] * size
        self.front = -1
        self.rear = -1

    def is_full(self):
        return (self.rear + 1) % self.size == self.front

    def is_empty(self):
        return self.front == -1

    def enqueue(self, x):
        if self.is_full():
            print("Queue is Full")
            return
        if self.front == -1:
            self.front = 0
        self.rear = (self.rear + 1) % self.size
        self.q[self.rear] = x
        print(x, "inserted at index", self.rear)

    def dequeue(self):
        if self.is_empty():
            print("Queue is Empty")
            return
        x = self.q[self.front]
        self.q[self.front] = None
        if self.front == self.rear:          # last element removed
            self.front = self.rear = -1
        else:
            self.front = (self.front + 1) % self.size
        print(x, "deleted")

    def display(self):
        if self.is_empty():
            print("Queue is Empty")
            return
        items = []
        i = self.front
        while True:
            items.append(self.q[i])
            if i == self.rear:
                break
            i = (i + 1) % self.size
        print("Queue (front -> rear):", items, "| front =", self.front, "rear =", self.rear)


cq = CircularQueue(int(input("Enter queue size: ")))
while True:
    print("\n----- CIRCULAR QUEUE -----")
    print("1. Enqueue\n2. Dequeue\n3. Display\n4. Exit")
    ch = input("Enter your choice: ").strip()
    if ch == "1":
        cq.enqueue(int(input("Enter value: ")))
    elif ch == "2":
        cq.dequeue()
    elif ch == "3":
        cq.display()
    elif ch == "4":
        break
    else:
        print("Invalid choice")
