# Practical B-2 : Simple (Linear) Queue using list
# Drawback: after dequeue the freed space at the front is never reused.

SIZE = 5
q = [None] * SIZE
front = -1
rear = -1


def enqueue(x):
    global front, rear
    if rear == SIZE - 1:
        print("Queue is Full (rear reached the end)")
        if front > 0:
            print("Drawback of simple queue: free space exists at the front but cannot be used.")
        return
    if front == -1:
        front = 0
    rear += 1
    q[rear] = x
    print(x, "inserted")


def dequeue():
    global front, rear
    if front == -1 or front > rear:
        print("Queue is Empty")
        return
    print(q[front], "deleted")
    q[front] = None
    front += 1


def display():
    if front == -1 or front > rear:
        print("Queue is Empty")
    else:
        print("Queue (front -> rear):", q[front:rear + 1])


while True:
    print("\n----- SIMPLE QUEUE -----")
    print("1. Enqueue\n2. Dequeue\n3. Display\n4. Exit")
    ch = input("Enter your choice: ").strip()
    if ch == "1":
        enqueue(int(input("Enter value: ")))
    elif ch == "2":
        dequeue()
    elif ch == "3":
        display()
    elif ch == "4":
        break
    else:
        print("Invalid choice")
