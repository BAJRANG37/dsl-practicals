# Practical D-4 : Tree traversals (inorder, preorder, postorder)
# Option 1 : create any binary tree by answering questions
# Option 2 : construct a binary tree from given Preorder + Inorder

class Node:
    def __init__(self, data):
        self.data = data
        self.left = None
        self.right = None


def create_tree():
    s = input("Enter node value (or 'x' for no node): ").strip()
    if s.lower() == "x":
        return None
    node = Node(s)
    print("  Left child of", s)
    node.left = create_tree()
    print("  Right child of", s)
    node.right = create_tree()
    return node


def build(pre, ino):
    if not pre:
        return None
    root = Node(pre[0])
    i = ino.index(root.data)             # split inorder at the root
    root.left = build(pre[1:1 + i], ino[:i])
    root.right = build(pre[1 + i:], ino[i + 1:])
    return root


def inorder(r):
    return [] if r is None else inorder(r.left) + [r.data] + inorder(r.right)


def preorder(r):
    return [] if r is None else [r.data] + preorder(r.left) + preorder(r.right)


def postorder(r):
    return [] if r is None else postorder(r.left) + postorder(r.right) + [r.data]


def show(root):
    print("Inorder   :", " ".join(inorder(root)))
    print("Preorder  :", " ".join(preorder(root)))
    print("Postorder :", " ".join(postorder(root)))


def main():
    while True:
        print("\n----- TREE TRAVERSALS -----")
        print("1. Create a tree and show traversals")
        print("2. Construct tree from Preorder + Inorder")
        print("3. Exit")
        ch = input("Enter your choice: ").strip()
        if ch == "1":
            root = create_tree()
            show(root)
        elif ch == "2":
            pre = input("Enter Preorder  (space separated): ").split()
            ino = input("Enter Inorder   (space separated): ").split()
            if sorted(pre) != sorted(ino):
                print("Preorder and Inorder do not contain the same nodes. Check the input.")
                continue
            try:
                root = build(pre, ino)
            except ValueError:
                print("These traversals do not match, so no tree can be built.")
                continue
            if preorder(root) != pre or inorder(root) != ino:
                print("These traversals do not match, so no tree can be built.")
                continue
            show(root)
        elif ch == "3":
            break
        else:
            print("Invalid choice")


main()
