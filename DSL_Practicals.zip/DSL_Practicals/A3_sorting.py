# Practical A-3 : Bubble Sort and Selection Sort (pass by pass output)

def bubble_sort(a):
    a = a[:]
    n = len(a)
    for i in range(n - 1):
        swapped = False
        for j in range(n - 1 - i):
            if a[j] > a[j + 1]:
                a[j], a[j + 1] = a[j + 1], a[j]
                swapped = True
        print("Pass", i + 1, ":", a)
        if not swapped:      # already sorted -> stop early
            break
    return a


def selection_sort(a):
    a = a[:]
    n = len(a)
    for i in range(n - 1):
        m = i                          # index of minimum element
        for j in range(i + 1, n):
            if a[j] < a[m]:
                m = j
        a[i], a[m] = a[m], a[i]
        print("Pass", i + 1, ":", a)
    return a


def main():
    a = [int(x) for x in input("Enter numbers separated by space: ").split()]
    while True:
        print("\n----- SORTING -----")
        print("1. Bubble Sort")
        print("2. Selection Sort")
        print("3. Enter a new list")
        print("4. Exit")
        ch = input("Enter your choice: ").strip()
        if ch == "1":
            print("Original:", a)
            print("Sorted  :", bubble_sort(a))
        elif ch == "2":
            print("Original:", a)
            print("Sorted  :", selection_sort(a))
        elif ch == "3":
            a = [int(x) for x in input("Enter numbers separated by space: ").split()]
        elif ch == "4":
            break
        else:
            print("Invalid choice")


main()
